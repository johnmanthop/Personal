#include <iostream>
#include <SFML/Graphics.hpp>

#include "scene.h"
#include "Player.h"

int main()
{
    sf::RenderWindow win(sf::VideoMode(576, 324), "ASD");

    Scene sc1("dependencies/Tiles/Background/Background.png");
    sc1.read_file("scene1.txt");
    sc1.init_map();

    Player pl("Dependencies/Characters/Woodcutter/Woodcutter_walk.png", 260, 200);

    while (win.isOpen())
    {
        win.setFramerateLimit(60);
        sf::Event ev;

        sc1.handle_collisions(pl);

        if (!pl.bdown) pl.set_ground_level(320);

        if (!sf::Keyboard::isKeyPressed(sf::Keyboard::A) &&
            !sf::Keyboard::isKeyPressed(sf::Keyboard::D)) pl.reset_anim();

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) || pl.is_jumping())
        {
            if (!pl.is_freefalling() && !pl.bup) pl.jump();
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) && !pl.bright)
        {
            sc1.go_right();
            pl.reverse_right();
            pl.animate_walk();
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) && !pl.bleft)
        {
            sc1.go_left();
            pl.reverse_left();
            pl.animate_walk();
        }

        if (pl.bup) pl.stop_jump();

        if (!pl.is_jumping()) pl.gravity();

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
        {//The scene is passed as a parameter for the hit mechanics
            pl.animate_cut(sc1);//Internally manages the hit function as well
        }
        else
        {
            pl.stop_cut();
        }

        pl.reset_blocks();

        while(win.pollEvent(ev))
        {
            if (ev.type == sf::Event::Closed)
                win.close();
        }

        win.clear();
        sc1.draw(win);
        pl.draw(win);
        win.display();
    }
    return 0;
}
