#include "player.h"
#include <iostream>

Person::Person(const char* fname, double _x, double _y):
    or1(0),
    or2(0),
    or3(48),
    or4(48)
{
    r1 = 0;
    r2 = 0;
    r3 = 48;
    r4 = 48;
    x = _x;
    y = _y;
    animation_rectangle = sf::IntRect(r1, r2, r3, r4);
    tx.loadFromFile(fname);
    sp.setTexture(tx);
    sp.setTextureRect(animation_rectangle);
    sp.setPosition(x, y);
}

Person::~Person()
{  }

void Person::set_position(double _x, double _y)
{
    x = _x;
    y = _y;
    sp.setPosition(x, y);
}


Player::Player(const char* fname, double _x, double _y):
    Person(fname, _x, _y),
    gravity_counter(0),
    ground_level(320),
    animation_counter(0),
    jump_counter(0),
    bleft(false),
    bright(false),
    bup(false),
    bdown(false),
    looks_right(true),
    trees_cut(0)
{
    cut_tx.loadFromFile("Dependencies/Characters/Woodcutter/Woodcutter_attack1.png");
    font.loadFromFile("Dependencies/Pixellari.ttf");
    text.setFont(font);
    text.setString("TREES CUT :" + std::to_string(trees_cut));
}

Player::~Player()
{
    //dtor
}

void Player::jump()
{
    jump_counter++;
    gravity_counter = 0;
    if (jump_counter > 20)
    {
        jump_counter = 0;//End jump here
        return;
    }
    if (jump_counter <= 10) y -= 3;
    else if (jump_counter <= 15) y -= 1.5;
    else if (jump_counter <= 20) y -= 0.7;
    sp.setPosition(x, y);//From now, gravity takes hold of the down motion
}

void Player::animate_walk()
{
    sp.setTexture(tx);
    animation_counter += 10;
    if (animation_counter < 60)
    {
        r1 = 0;
        animation_rectangle = sf::IntRect((looks_right)?r1:48, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (animation_counter < 120)
    {
        r1 = 48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (animation_counter < 180)
    {
        r1 = 2*48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (animation_counter < 240)
    {
        r1 = 3*48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (animation_counter < 300)
    {
        r1 = 4*48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (animation_counter < 360)
    {
        r1 = 5*48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else
    {
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
        animation_counter = 0;
    }
}

void Player::animate_cut(Scene& s)
{
    sp.setTexture(cut_tx);
    cut_animation_counter += 25;
    if (cut_animation_counter < 60)
    {
        r1 = 0;
        animation_rectangle = sf::IntRect(looks_right?r1:48, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (cut_animation_counter < 120)
    {
        r1 = 48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (cut_animation_counter < 180)
    {
        r1 = 2*48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (cut_animation_counter < 240)
    {
        r1 = 3*48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (cut_animation_counter < 300)
    {
        r1 = 4*48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else if (cut_animation_counter < 360)
    {
        r1 = 5*48;
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
    }
    else
    {
        hit(s);
        animation_rectangle = sf::IntRect(r1, r2, (looks_right)?r3:-r3, r4);
        sp.setTextureRect(animation_rectangle);
        cut_animation_counter = 0;
    }
}

void Player::gravity()
{
    if (y+48 < ground_level)
    {
        y += GRAVITY_CONSTANT*(++gravity_counter);
        sp.setPosition(x, y);
    }
    else
    {
        gravity_counter = 0;
        y = ground_level - 48;
        sp.setPosition(x, y);
    }
}

void Player::reset_anim()
{
    r1 = 0;
    sp.setTexture(tx);
    animation_rectangle = sf::IntRect((looks_right)?r1:48, r2, (looks_right)?r3:-r3, r4);
    sp.setTextureRect(animation_rectangle);
}

void Player::reverse_left()
{
    looks_right = false;
}

void Player::reverse_right()
{
    looks_right = true;
}

void Player::hit(Scene& s)
{
    General_Block* temp_tile = s.get_tile_with_coordinate(x+24, y+24);
    if (temp_tile)
    {
        if (temp_tile->hit() == -1) trees_cut++;
        text.setString("TREES CUT :" + std::to_string(trees_cut));
    }
    //Don't delete the tile since it is owned by the scene class
}
