#ifndef PLAYER_H
#define PLAYER_H
#include <iostream>
#include <SFML/Graphics.hpp>

#include "scene.h"

#define GRAVITY_CONSTANT 0.5

class Scene;

class Person
{
protected:
    sf::Sprite sp;
    sf::Texture tx;
    double x, y;
    double r1, r2, r3, r4;
    const double or1, or2, or3, or4;
    sf::IntRect animation_rectangle;
public:
    Person(const char* fname);//Probably won't get used but whatever
    Person(const char* fname, double _x, double _y);
    ~Person();

    const sf::Sprite& get_sp() const{ return sp; }

    void set_position(double _x, double _y);
};

class Player : public Person
{
    double ground_level;
    int gravity_counter;
    //This indicates where the ground coordinate should be
    //Ex: On a platform the ground coordinate is higher than when
    //the player is on the floor level
    double animation_counter;//Probably should abstract the animation to a separate class
    double cut_animation_counter;
    int jump_counter;
    sf::Texture cut_tx;
    bool looks_right;
    int trees_cut;
    sf::Text text;
    sf::Font font;
public:
    bool bup, bdown, bleft, bright;
    Player(const char* fname, double _x, double _y);
    ~Player();

    void jump();
    void gravity();//These two work together

    void animate_walk();
    void animate_cut(Scene& s);

    void set_ground_level(double _g) { ground_level = _g; }

    double get_x() { return x; }
    double get_y() { return y; }

    const bool is_jumping() { return jump_counter >= 1; }
    const bool is_cutting() { return cut_animation_counter > 0; }
    const bool is_freefalling()
    {
        return y + 48 < ground_level && jump_counter == 0;
    }

    void reverse_left();
    void reverse_right();
    void reset_anim();

    void stop_cut() { cut_animation_counter = 0; }
    void stop_jump() { jump_counter = 0; }

    void draw(sf::RenderWindow& win) { win.draw(sp); win.draw(text); }
    //All objects are responsible for drawing themselvs

    void reset_blocks()
    {
        bleft = bright = bup = bdown = false;
    }
    void hit(Scene& s);
    void add_tree() { trees_cut++; }
};

#endif // PLAYER_H
